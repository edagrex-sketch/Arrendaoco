<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\InmuebleController;
use App\Http\Controllers\Api\ContratoController;
use App\Http\Controllers\Api\PagoController;
use App\Http\Controllers\Api\ReporteController;

/*
|--------------------------------------------------------------------------
| Auth
|--------------------------------------------------------------------------
*/
Route::post('/login', [AuthController::class, 'login']);

/*
|--------------------------------------------------------------------------
| Rutas protegidas
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {

    // Auth
    Route::post('/logout', [AuthController::class, 'logout']);

    // ✅ Esto regresa tu App\Models\Usuario (aunque la función se llame user())
    Route::get('/me', function () {
        return auth()->user();
    });

    // Inmuebles
    Route::apiResource('inmuebles', InmuebleController::class)->names('api.inmuebles');

    // Contratos
    Route::post('/inmuebles/{inmueble}/rentar', [ContratoController::class, 'rentar']);
    Route::post('/contratos/{contrato}/renovar', [ContratoController::class, 'renovar']);
    Route::post('/contratos/{contrato}/cancelar', [ContratoController::class, 'cancelar']);

    // Estado de cuenta (JSON)
    Route::get('/contratos/{contrato}/estado-cuenta', [ContratoController::class, 'estadoCuenta']);

    // Pagos
    Route::post('/contratos/{contrato}/pagos/generar', [PagoController::class, 'generar']);
    Route::post('/pagos/{pago}/pagar', [PagoController::class, 'pagar']);

    // Reportes
    Route::get('/reportes/ingresos', [ReporteController::class, 'ingresos']);

    // Excel
    Route::get('/contratos/{contrato}/estado-cuenta/excel', [ContratoController::class, 'exportarEstadoCuentaExcel']);
});
