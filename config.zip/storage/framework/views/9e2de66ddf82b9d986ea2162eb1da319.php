<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // --- 1. GESTIÓN DEL NOMBRE ---
        <?php if(auth()->guard()->check()): ?>
            // Simulación de llamada a backend o uso de cache local
            const savedName = localStorage.getItem('yayitoName') || 'Yayito';
            updateMascotNameUI(savedName);
        <?php else: ?>
            const savedName = localStorage.getItem('yayitoName') || 'Yayito';
            updateMascotNameUI(savedName);
        <?php endif; ?>

        // --- 2. LOGICA DEL OVERLAY ---
        const overlay = document.getElementById('lock-overlay');
        if(overlay) {
            // Ocultar overlay después de 2.5 segundos
            setTimeout(() => { 
                overlay.classList.add('overlay-hidden'); 
            }, 2500);
        }
    });

    /**
     * Actualiza el texto en la burbuja
     */
    function updateMascotNameUI(name) {
        const display = document.getElementById('mascot-name-display');
        if(display) display.textContent = name;
    }

    /**
     * Función para cambiar nombre (SweetAlert2 personalizado)
     */
    function renameMascot() {
        // Hacemos que salte antes de abrir el modal
        playWithYayito();

        Swal.fire({
            title: '¡Squawk! 🦜',
            text: '¿Qué nombre prefieres para mí?',
            input: 'text',
            inputValue: localStorage.getItem('yayitoName') || 'Yayito',
            showCancelButton: true,
            confirmButtonText: 'Guardar Nombre',
            confirmButtonColor: '#D32F2F', // Rojo Yayito
            cancelButtonColor: '#1565C0',  // Azul Yayito
            background: '#fff',
            customClass: {
                popup: 'rounded-xl border-4 border-blue-100'
            },
            inputValidator: (value) => {
                if (!value) return '¡Necesito un nombre para hablar!';
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const newName = result.value;
                localStorage.setItem('yayitoName', newName);
                updateMascotNameUI(newName);
                
                // Mensaje de éxito
                Swal.fire({
                    title: `¡Entendido!`,
                    html: `Ahora soy <b>${newName}</b>. <br>¡Listo para volar!`,
                    icon: 'success',
                    timer: 2000,
                    showConfirmButton: false
                });
            }
        });
    }

    /**
     * Animación de interacción (Salto y aleteo)
     */
    function playWithYayito() {
        const actor = document.getElementById('yayito-actor');
        
        if(actor && !actor.classList.contains('squawk-anim')) {
            // Agregar clase de animación
            actor.classList.add('squawk-anim');
            
            // Opcional: Sonido de interfaz suave si lo deseas
            // playSystemSound(); 

            // Quitar la clase al terminar para poder repetir
            setTimeout(() => {
                actor.classList.remove('squawk-anim');
            }, 500); // 500ms dura la animación CSS
        }
    }
</script>
<?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/components/yayito/scripts.blade.php ENDPATH**/ ?>