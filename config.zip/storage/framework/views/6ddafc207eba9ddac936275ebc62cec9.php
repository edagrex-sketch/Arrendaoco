
<div id="lock-overlay">
    <div class="loader-content">
        
        <div class="feather-loader"></div>
    </div>
    <h3 id="lock-message" class="mt-8 text-2xl font-bold text-[#D32F2F] animate-pulse text-center px-4">
        <?php if(auth()->guard()->check()): ?>
            ¡Bienvenido al nido! 🦜
        <?php else: ?>
            Preparando el vuelo...
            <span class="block text-sm font-normal text-gray-500 mt-2">Cargando recursos...</span>
        <?php endif; ?>
    </h3>
</div>


<div id="mascot-wrapper">

    
    <div class="mascot-bubble" onclick="renameMascot()">
        <div class="bubble-text">
            ¡Squawk! Soy <span id="mascot-name-display" class="mascot-name-highlight">Yayito</span>.
        </div>
        <div class="bubble-sub">
            Clic en mí para ayuda
        </div>
    </div>

    
    <div class="yayito-container" onclick="playWithYayito()" id="yayito-actor">
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="yayito-svg">
            <g class="branch-group">
                <path d="M10,160 Q60,165 100,155 T190,160" stroke="#5D4037" stroke-width="8" fill="none" stroke-linecap="round"/>
                <path d="M180,160 Q190,140 200,150" stroke="#4CAF50" stroke-width="4" fill="none"/>
                <path d="M20,160 Q10,140 0,150" stroke="#4CAF50" stroke-width="4" fill="none"/>
            </g>

            <g class="bird-body-group">
                <path d="M80,140 L60,200 L90,190 Z" fill="#D32F2F" /> 
                <path d="M80,140 L80,210 L100,190 Z" fill="#1976D2" />

                <ellipse cx="100" cy="110" rx="35" ry="50" fill="#D32F2F" />
                
                <ellipse cx="100" cy="115" rx="20" ry="35" fill="#E57373" opacity="0.5" />

                <g class="wing">
                    <path d="M75,90 Q55,120 75,140 Q100,130 100,100 Z" fill="#D32F2F" />
                    <path d="M75,100 Q60,120 75,135" stroke="#FBC02D" stroke-width="8" fill="none" stroke-linecap="round"/>
                    <path d="M70,115 Q60,125 70,135" stroke="#1565C0" stroke-width="6" fill="none" stroke-linecap="round"/>
                </g>

                <circle cx="100" cy="75" r="28" fill="#D32F2F" />
                
                <path d="M100,60 Q125,60 125,80 Q115,95 100,90 Z" fill="white" />

                <g class="eye-group">
                    <circle cx="112" cy="75" r="3" fill="#333" />
                    <circle cx="113" cy="73" r="1" fill="white" /> </g>

                <path d="M120,70 Q145,80 120,95 Z" fill="#FFECB3" /> <path d="M120,70 Q145,80 120,95" stroke="#333" stroke-width="1" fill="none" opacity="0.2"/>
                <path d="M120,92 Q130,95 120,100 Z" fill="#3E2723" /> <path d="M90,155 L90,165" stroke="#CCC" stroke-width="4" stroke-linecap="round"/>
                <path d="M110,155 L110,165" stroke="#CCC" stroke-width="4" stroke-linecap="round"/>
            </g>
        </svg>
    </div>
</div>
<?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/components/yayito/view.blade.php ENDPATH**/ ?>