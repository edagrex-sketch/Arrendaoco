<?php $__env->startSection('title', 'Publicar Inmueble'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto" x-data="wizardForm">

        
        <div class="mb-8 text-center">
            <h1 class="text-3xl font-bold text-foreground mb-4">Publicar Propiedad</h1>
            <div class="flex items-center justify-center gap-4 relative">
                <div class="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10 rounded-full"></div>
                <div class="flex flex-col items-center cursor-pointer" @click="if(step > 1) step = 1">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold border-4 transition-colors bg-white z-10"
                        :class="step >= 1 ? 'border-primary text-primary' : 'border-gray-300 text-gray-400'">1</div>
                    <span class="text-xs font-medium mt-1 bg-background px-1"
                        :class="step >= 1 ? 'text-primary' : 'text-gray-400'">Básico</span>
                </div>
                <div class="flex flex-col items-center">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold border-4 transition-colors bg-white z-10"
                        :class="step >= 2 ? 'border-primary text-primary' : 'border-gray-300 text-gray-400'">2</div>
                    <span class="text-xs font-medium mt-1 bg-background px-1"
                        :class="step >= 2 ? 'text-primary' : 'text-gray-400'">Detalles</span>
                </div>
                <div class="flex flex-col items-center">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center font-bold border-4 transition-colors bg-white z-10"
                        :class="step >= 3 ? 'border-primary text-primary' : 'border-gray-300 text-gray-400'">3</div>
                    <span class="text-xs font-medium mt-1 bg-background px-1"
                        :class="step >= 3 ? 'text-primary' : 'text-gray-400'">Fotos</span>
                </div>
            </div>
        </div>

        
        <div class="bg-card border border-border rounded-2xl shadow-lg p-6 sm:p-8">
            <form method="POST" action="<?php echo e(route('inmuebles.guardar')); ?>" class="space-y-6" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div x-show="step === 1" x-ref="step1"
                    x-transition:enter="transition opacity-0 transform translate-x-4 ease-out duration-300"
                    x-transition:enter-start="opacity-0 translate-x-4" x-transition:enter-end="opacity-100 translate-x-0">
                    <h2 class="text-xl font-bold mb-4 flex items-center gap-2">🏠 ¿Qué vas a rentar?</h2>
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label class="block text-sm font-medium mb-1">Nombre del Anuncio <span
                                    class="text-red-500">*</span></label>
                            <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>"
                                placeholder="Ej. Depa moderno cerca de la UTC" required
                                class="w-full rounded-lg border-input bg-background/50 border py-3 px-4 focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium mb-1">Tipo <span
                                        class="text-red-500">*</span></label>
                                <select name="tipo" required
                                    class="w-full rounded-lg border-input bg-background/50 border py-3 px-4">
                                    <option value="Casa" <?php echo e(old('tipo') == 'Casa' ? 'selected' : ''); ?>>Casa</option>
                                    <option value="Departamento" <?php echo e(old('tipo') == 'Departamento' ? 'selected' : ''); ?>>
                                        Departamento</option>
                                    <option value="Local" <?php echo e(old('tipo') == 'Local' ? 'selected' : ''); ?>>Local</option>
                                    <option value="Cuarto" <?php echo e(old('tipo') == 'Cuarto' ? 'selected' : ''); ?>>Cuarto</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium mb-1">Precio <span
                                        class="text-red-500">*</span></label>
                                <div class="relative">
                                    <span class="absolute left-3 top-3 text-gray-500">$</span>
                                    <input type="number" name="precio" value="<?php echo e(old('precio')); ?>" placeholder="0.00"
                                        required
                                        class="w-full rounded-lg border-input bg-background/50 border py-3 pl-8 px-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div x-show="step === 2" x-ref="step2" x-transition style="display: none;">
                    <h2 class="text-xl font-bold mb-4 flex items-center gap-2">✨ Características y Ubicación</h2>

                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Dirección Completa <span
                                class="text-red-500">*</span></label>
                        <div class="flex gap-2">
                            <input type="text" name="direccion" id="direccion-input" value="<?php echo e(old('direccion')); ?>"
                                placeholder="Calle, Número, Colonia..." required
                                class="flex-1 rounded-lg border-input bg-background/50 border py-3 px-4">
                            <button type="button" onclick="buscarDireccion()"
                                class="bg-primary/10 text-primary border border-primary/20 px-4 py-2 rounded-lg hover:bg-primary hover:text-white transition-all text-sm font-bold flex items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                Buscar en mapa
                            </button>
                        </div>
                    </div>

                    
                    <div class="mb-6">
                        <label class="block text-sm font-medium mb-2">Marca el punto en el mapa <span
                                class="text-xs text-muted-foreground font-normal">(Seleccionado automáticamente al buscar
                                dirección)</span></label>
                        <div id="map-picker"
                            class="w-full h-[300px] rounded-xl border border-border bg-slate-50 z-10 shadow-inner"></div>
                        <input type="hidden" name="latitud" id="lat-input" value="<?php echo e(old('latitud')); ?>">
                        <input type="hidden" name="longitud" id="lng-input" value="<?php echo e(old('longitud')); ?>">
                    </div>

                    
                    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

                    <div class="grid grid-cols-3 gap-4 mb-4">
                        <div>
                            <label class="block text-xs font-medium mb-1 uppercase text-muted-foreground">Habitaciones <span
                                    class="text-red-500">*</span></label>
                            <input type="number" name="habitaciones" value="<?php echo e(old('habitaciones')); ?>" required
                                class="w-full rounded-lg border-input bg-background/50 border py-2 px-3">
                        </div>
                        <div>
                            <label class="block text-xs font-medium mb-1 uppercase text-muted-foreground">Baños <span
                                    class="text-red-500">*</span></label>
                            <input type="number" name="banos" value="<?php echo e(old('banos')); ?>" required
                                class="w-full rounded-lg border-input bg-background/50 border py-2 px-3">
                        </div>
                        <div>
                            <label class="block text-xs font-medium mb-1 uppercase text-muted-foreground">m² <span
                                    class="text-red-500">*</span></label>
                            <input type="number" name="metros" value="<?php echo e(old('metros')); ?>" required
                                class="w-full rounded-lg border-input bg-background/50 border py-2 px-3">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Descripción <span
                                class="text-red-500">*</span></label>
                        <textarea name="descripcion" rows="4" placeholder="Cuéntanos más detalles..." required
                            class="w-full rounded-lg border-input bg-background/50 border py-3 px-4"><?php echo e(old('descripcion')); ?></textarea>
                    </div>
                </div>

                
                <div x-show="step === 3" x-ref="step3" x-transition style="display: none;">
                    <h2 class="text-xl font-bold mb-4 flex items-center gap-2">📷 Galería de Fotos</h2>

                    <div class="mb-6">
                        <label class="block text-sm font-medium mb-1">Subir Fotos <span
                                class="text-red-500">*</span></label>

                        <div
                            class="relative group cursor-pointer hover:bg-slate-50 transition-colors rounded-xl border-2 border-dashed border-gray-300 p-8 flex flex-col items-center justify-center text-center">

                            
                            <input type="file" id="fileInput" name="imagenes[]" multiple accept="image/*"
                                class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                @change="handleFileSelect">

                            <div class="text-primary-400 mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 mx-auto text-muted-foreground"
                                    fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            </div>
                            <p class="text-sm font-medium text-foreground">Haz clic o arrastra más fotos</p>
                        </div>
                    </div>

                    
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6" x-show="previews.length > 0">
                        <template x-for="(img, index) in previews" :key="index">
                            <div class="relative group aspect-square rounded-lg shadow-sm border border-gray-200"
                                style="position: relative;">
                                
                                <img :src="img" class="object-cover w-full h-full rounded-lg">

                                
                                <button type="button" @click="removeFile(index)"
                                    style="position: absolute; top: -12px; right: -12px; background-color: #EF4444; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; z-index: 9999; border: 3px solid white; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.15);"
                                    title="Eliminar foto">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        style="width: 16px; height: 16px; font-weight: bold;" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </template>
                    </div>
                </div>

                <div class="pt-6 border-t border-border flex justify-between items-center mt-6">
                    <button type="button" @click="step--" x-show="step > 1"
                        class="text-muted-foreground hover:text-foreground font-medium px-4 py-2 transition-colors">←
                        Atrás</button>
                    <div x-show="step === 1"></div>
                    <button type="button" @click="nextStep()" x-show="step < 3"
                        class="bg-primary text-primary-foreground font-bold py-2 px-6 rounded-xl hover:bg-primary/90 transition-all shadow-md shadow-primary/20">Siguiente
                        Paso →</button>

                    <button type="submit" x-show="step === 3"
                        style="background-color: #16a34a; color: white; padding: 12px 32px; border-radius: 12px; font-weight: bold; font-size: 16px; border: none; cursor: pointer; box-shadow: 0 4px 10px rgba(22, 163, 74, 0.4); display: flex; align-items: center; gap: 8px;">
                        <span>✨</span> ¡Publicar Ahora!
                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        var mapPicker, markerPicker;

        function initMapPicker() {
            if (mapPicker) return;
            setTimeout(() => {
                mapPicker = L.map('map-picker').setView([16.9068, -92.0941], 14);

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors'
                }).addTo(mapPicker);

                mapPicker.on('click', function(e) {
                    actualizarPin(e.latlng.lat, e.latlng.lng);
                });

                mapPicker.invalidateSize();
            }, 50);
        }

        function actualizarPin(lat, lng, zoom = null) {
            if (markerPicker) {
                markerPicker.setLatLng([lat, lng]);
            } else {
                markerPicker = L.marker([lat, lng]).addTo(mapPicker);
            }
            document.getElementById('lat-input').value = lat;
            document.getElementById('lng-input').value = lng;

            if (zoom) {
                mapPicker.setView([lat, lng], zoom);
            }
        }

        async function buscarDireccion() {
            const direccionRaw = document.getElementById('direccion-input').value;
            if (!direccionRaw) return;

            // Añadimos contexto para mejorar la precisión en Ocosingo
            const query = encodeURIComponent(direccionRaw + ", Ocosingo, Chiapas, México");
            const btn = event.currentTarget;
            const originalText = btn.innerHTML;

            btn.innerHTML = "🔍 Buscando...";
            btn.disabled = true;

            try {
                const response = await fetch(
                    `https://nominatim.openstreetmap.org/search?format=json&q=${query}&limit=1`);
                const data = await response.json();

                if (data && data.length > 0) {
                    const lat = parseFloat(data[0].lat);
                    const lon = parseFloat(data[0].lon);
                    actualizarPin(lat, lon, 17); // Zoom más cercano al encontrar dirección
                } else {
                    alert("No pudimos encontrar esa calle exacta. ¿Podrías marcar el punto manualmente en el mapa? 🐾");
                }
            } catch (error) {
                console.error("Error en geocodificación:", error);
            } finally {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        }

        document.addEventListener('alpine:init', () => {
            Alpine.data('wizardForm', () => ({
                step: 1,
                files: [],
                previews: [],

                handleFileSelect(event) {
                    const newFiles = Array.from(event.target.files);
                    this.files = this.files.concat(newFiles);
                    newFiles.forEach(file => {
                        const reader = new FileReader();
                        reader.onload = (e) => this.previews.push(e.target.result);
                        reader.readAsDataURL(file);
                    });
                    this.updateInputFiles();
                },

                removeFile(index) {
                    this.files.splice(index, 1);
                    this.previews.splice(index, 1);
                    this.updateInputFiles();
                },

                updateInputFiles() {
                    const dataTransfer = new DataTransfer();
                    this.files.forEach(file => dataTransfer.items.add(file));
                    document.getElementById('fileInput').files = dataTransfer.files;
                },

                nextStep() {
                    let currentDiv = this.$refs['step' + this.step];
                    let inputs = currentDiv.querySelectorAll(
                        'input:required, select:required, textarea:required');

                    let esValido = true;
                    for (let input of inputs) {
                        if (!input.checkValidity()) {
                            input.reportValidity();
                            esValido = false;
                            break;
                        }
                    }

                    if (esValido) {
                        this.step++;
                        if (this.step === 2) {
                            initMapPicker();
                        }
                    }
                }
            }))
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/inmuebles/create.blade.php ENDPATH**/ ?>