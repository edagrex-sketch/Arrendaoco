<?php $__env->startSection('title', 'Gestión de Usuarios - Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-[#003049]">Gestión de Usuarios</h1>
        <div class="flex gap-2">
            <a href="<?php echo e(route('admin.usuarios.create')); ?>" class="bg-[#669BBC] text-white px-4 py-2 rounded-lg hover:bg-[#003049] transition-colors">
                Crear Usuario
            </a>
            <a href="<?php echo e(route('admin.usuarios.reporte')); ?>" class="bg-[#C1121F] text-white px-4 py-2 rounded-lg hover:bg-[#780000] transition-colors">
                Reporte PDF
            </a>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-[#003049] text-white">
                <tr>
                    <th class="px-6 py-3 text-left">ID</th>
                    <th class="px-6 py-3 text-left">Nombre</th>
                    <th class="px-6 py-3 text-left">Email</th>
                    <th class="px-6 py-3 text-left">Roles</th>
                    <th class="px-6 py-3 text-left">Estatus</th>
                    <th class="px-6 py-3 text-center">Acciones</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4"><?php echo e($usuario->id); ?></td>
                    <td class="px-6 py-4 font-medium"><?php echo e($usuario->nombre); ?></td>
                    <td class="px-6 py-4"><?php echo e($usuario->email); ?></td>
                    <td class="px-6 py-4">
                        <?php $__currentLoopData = $usuario->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">
                                <?php echo e($role->etiqueta ?? $role->nombre); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded-full text-xs font-bold <?php echo e($usuario->estatus === 'activo' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e(ucfirst($usuario->estatus)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-center">
                        <div class="flex justify-center gap-2">
                            <a href="<?php echo e(route('admin.usuarios.edit', $usuario->id)); ?>" class="text-[#669BBC] hover:text-[#003049]">
                                Editar
                            </a>
                            <button onclick="confirmDelete(<?php echo e($usuario->id); ?>)" class="text-[#C1121F] hover:text-[#780000]">
                                Eliminar
                            </button>
                        </div>
                        <form id="delete-form-<?php echo e($usuario->id); ?>" action="<?php echo e(route('admin.usuarios.destroy', $usuario->id)); ?>" method="POST" class="hidden">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>