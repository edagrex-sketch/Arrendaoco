

<?php echo $__env->make('components.arrendito.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('components.arrendito.view', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('components.arrendito.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/components/arrendito.blade.php ENDPATH**/ ?>