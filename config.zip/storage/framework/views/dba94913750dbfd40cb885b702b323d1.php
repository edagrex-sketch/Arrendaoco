<style>
    :root {
        --yayito-red: #D32F2F;
        --yayito-blue: #1565C0;
        --yayito-yellow: #FBC02D;
        --text-color: #333;
    }

    /* --- OVERLAY --- */
    #lock-overlay {
        position: fixed;
        inset: 0;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at center, #fff, #f0f0f0);
        transition: opacity 0.8s ease-out, visibility 0.8s;
    }
    .overlay-hidden {
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }

    /* Loader sencillo con CSS (Pluma girando) */
    .feather-loader {
        width: 50px;
        height: 50px;
        border: 5px solid #eee;
        border-top: 5px solid var(--yayito-red);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

    /* --- CONTENEDOR YAYITO --- */
    #mascot-wrapper {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9000;
        display: flex;
        flex-direction: column;
        align-items: flex-end;
    }

    /* GLOBO DE TEXTO */
    .mascot-bubble {
        background: white;
        border-left: 5px solid var(--yayito-blue);
        padding: 12px 16px;
        border-radius: 15px 15px 0 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        margin-bottom: -20px; /* Superposición */
        margin-right: 30px;
        max-width: 220px;
        opacity: 0;
        transform: translateY(10px);
        animation: bubbleIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards 1.5s;
        cursor: pointer;
        z-index: 9002;
    }
    .mascot-name-highlight { color: var(--yayito-red); font-weight: 800; }
    .bubble-sub { font-size: 0.75rem; color: #888; margin-top: 2px; }

    /* SVG CONTAINER */
    .yayito-container {
        width: 160px;
        height: 160px;
        cursor: pointer;
        position: relative;
        z-index: 9001;
        transition: transform 0.2s;
    }
    .yayito-container:hover {
        transform: scale(1.05);
    }

    /* --- ANIMACIONES INTERNAS DEL SVG --- */
    
    /* 1. La Rama se mece */
    .branch-group {
        transform-origin: 100px 160px;
        animation: swayBranch 5s ease-in-out infinite;
    }

    /* 2. El cuerpo de Yayito respira/flota */
    .bird-body-group {
        animation: breathe 3s ease-in-out infinite;
        transform-origin: center bottom;
    }

    /* 3. Parpadeo */
    .eye-group {
        animation: blink 4s infinite;
        transform-origin: 112px 75px;
    }

    /* KEYFRAMES */
    @keyframes bubbleIn { to { opacity: 1; transform: translateY(0); } }
    
    @keyframes swayBranch {
        0%, 100% { transform: rotate(0deg); }
        50% { transform: rotate(2deg); }
    }

    @keyframes breathe {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-3px); }
    }

    @keyframes blink {
        0%, 96%, 100% { transform: scaleY(1); }
        98% { transform: scaleY(0.1); }
    }

    /* CLASES DE INTERACCIÓN JS */
    .squawk-anim {
        animation: squawkJump 0.5s ease-out;
    }

    @keyframes squawkJump {
        0% { transform: scale(1); }
        40% { transform: scale(1.1) translateY(-20px) rotate(-10deg); }
        60% { transform: scale(1.1) translateY(-20px) rotate(10deg); }
        100% { transform: scale(1) translateY(0) rotate(0); }
    }
</style>
<?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/components/yayito/styles.blade.php ENDPATH**/ ?>