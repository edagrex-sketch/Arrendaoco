<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Usuarios</title>
    <style>
        body { font-family: sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #003049; color: white; }
        h1 { color: #003049; }
        .footer { position: fixed; bottom: 0; width: 100%; text-align: center; font-size: 10px; color: #555; }
    </style>
</head>
<body>
    <h1>Reporte de Usuarios - ArrendaOco</h1>
    <p>Fecha de generación: <?php echo e(date('d/m/Y H:i')); ?></p>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Roles</th>
                <th>Estatus</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->id); ?></td>
                <td><?php echo e($usuario->nombre); ?></td>
                <td><?php echo e($usuario->email); ?></td>
                <td>
                    <?php $__currentLoopData = $usuario->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($role->etiqueta); ?><?php echo e(!$loop->last ? ', ' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e(ucfirst($usuario->estatus)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        Generado por ArrendaOco System
    </div>
</body>
</html>
<?php /**PATH C:\webapps\laravel\ArrendaOco_git\Arrendaoco\resources\views/admin/usuarios/reporte.blade.php ENDPATH**/ ?>