{{-- 
    Componente: Arrendito (Agente de Acompañamiento UX)
    Uso: <x-arrendito />
--}}

@include('components.arrendito.styles')

@include('components.arrendito.view')

@include('components.arrendito.scripts')
