<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ArrendaOco</title>
    @vite('resources/js/app.js')
</head>
<body>
    <div id="app"></div>
</body>
</html>
