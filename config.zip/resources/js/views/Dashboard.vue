<template>
  <div>
    <h1>Dashboard</h1>
    <p>Bienvenido a ArrendaOco</p>
  </div>
</template>
