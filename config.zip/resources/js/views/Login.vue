<template>
  <div>
    <h1>Login</h1>
    <p>Pantalla de login</p>
  </div>
</template>
